#include<stdio.h>
#include<conio.h>

int main()
{
    int a;
    int b;
    int sum;
    printf("Please enter the any number of a is : ");
    scanf("%d",&a);

    printf("Please enter the any number of b is : ");
    scanf("%d",&b);

    sum = a+ b;

    printf("total number is : ",sum);
    return 0;
}