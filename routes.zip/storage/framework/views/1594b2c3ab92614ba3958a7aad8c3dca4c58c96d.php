
<?php $__env->startSection('content'); ?>
<div class="card-body">
    <h4 class="card-title">All Blog</h4>
    <div class="table-responsive">
      <table class="table table-striped">
        <thead>
          <tr>
            <th>
              ID
            </th>
            <th>
              Title
            </th>
            <th>
              Duration
            </th>
            <th>
              Total Classes
            </th>
            <th>
              Seat
            </th>
            <th>
              Featured Image
            </th>
            <th>
              Created At
            </th>
            <th>
              Action
            </th>
          </tr>
        </thead>
        <tbody>
        <?php $__currentLoopData = $detailsCourse; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
          
          <td>
              <?php echo e($item->id); ?>

          </td>
          
          <td>
            <?php echo e($item->title); ?>

          </td>
          <td>
            <?php echo e($item->duration); ?>

          </td>
          <td>
            <?php echo e($item->total_class); ?>

          </td>
          <td>
            <?php echo e($item->total_seat); ?>

          </td>
          <td class="py-1">
            <img src="<?php echo e(asset($item->image)); ?>" alt="image" width="50px"/>
          </td>
          <td>
            <?php echo e($item->created_at); ?>

          </td>
          <td>
            <a class="badge bg-warning" style="color: black;" href="<?php echo e(route('editcourse', $item->id)); ?>">Edit</a>
            <a class="badge bg-primary" style="color: white;"  href="#">View</a>
            <a class="badge bg-danger" style="color: white;"  href="<?php echo e(route('deletecourse', $item->id)); ?>">Delete</a>
          </td>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>           
      </tbody>
      </table>
    </div>
  </div>
  <?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/jolchobi/public_html/resources/views/admin/allcourse.blade.php ENDPATH**/ ?>