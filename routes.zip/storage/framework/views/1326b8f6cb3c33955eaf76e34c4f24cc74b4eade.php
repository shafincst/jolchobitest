<div class="flex pl-28">
    <img src="<?php echo e(asset('admin/assets/images/fevicon.png')); ?>" alt="" width="20%">
    <h1 style="font-size: 40px">জলছবি</h1>
</div>
<?php /**PATH /home/jolchobi/test.jolchobi.org/resources/views/components/application-logo.blade.php ENDPATH**/ ?>