
<?php $__env->startSection('content'); ?>
<div class="card-body">
  <h4 class="card-title">All Blog</h4>
  <div class="table-responsive" style="width: 100%">
    <table class="table table-striped text-center">
      <thead>
        <tr>
          <th>
            Id
          </th>
          <th>
            Title
          </th>
          <th>
            Created At
          </th>
          <th>
            Image
          </th>
          <th>
            Action
          </th>
        </tr>
      </thead>
      <tbody>
        <?php $__currentLoopData = $details; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
          
          <td>
              <?php echo e($item->id); ?>

          </td>
          
          <td>
            <?php echo e($item->title); ?>

          </td>
          <td>
            <?php echo e($item->created_at); ?>

          </td>
          <td class="py-1">
            <img src="<?php echo e(asset($item->image)); ?>" alt="image" width="50px"/>
          </td>
          <td>
            <a class="badge bg-warning" style="color: black;" href="<?php echo e(route('editblog', $item->id)); ?>">Edit</a>
            <a class="badge bg-primary" style="color: white;"  href="#">View</a>
            <a class="badge bg-danger" style="color: white;"  href="<?php echo e(route('deleteblog', $item->id)); ?>">Delete</a>
          </td>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>           
      </tbody>
    </table>
  </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/jolchobi/public_html/resources/views/admin/allblog.blade.php ENDPATH**/ ?>