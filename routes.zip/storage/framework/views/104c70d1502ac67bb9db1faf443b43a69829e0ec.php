
<?php $__env->startSection('content'); ?>
<h3 class="font-weight-bold">Welcome <?php echo e(Auth::user()->name); ?></h3>

    <div style="width: 100rem;" class="d-flex">
        <div class="card text-center" style="width: 15rem; margin: 50px;">
            <div class="card-body">
                <h5 class="card-title">Total Post</h5>
                <h1><?php echo e($count); ?></h1>
                <a href="<?php echo e(route('addblog')); ?>" class="badge bg-primary" style="color: white;">Add Post</a>
                <a href="<?php echo e(route('allblog')); ?>" class="badge bg-danger" style="color: white;">All Post</a>
            </div>
        </div>
    
        <div class="card text-center" style="width: 15rem; margin: 50px;">
            <div class="card-body">
                <h5 class="card-title">Users</h5>
                <h1><?php echo e($count_user); ?></h1>
                <a href="#" class="badge bg-primary" style="color: white;">All Users</a>
            </div>
        </div>
    
        <div class="card text-center" style="width: 15rem; margin: 50px;">
            <div class="card-body">
                <h5 class="card-title">Total Course</h5>
                <h1>00</h1>
                <a href="#" class="badge bg-primary" style="color: white;">Add Course</a>
                <a href="#" class="badge bg-danger" style="color: white;">All Course</a>
            </div>
        </div>
    </div>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\jolchobi\resources\views/admin/dashboard.blade.php ENDPATH**/ ?>