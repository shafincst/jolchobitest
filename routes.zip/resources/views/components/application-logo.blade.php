<div class="flex pl-28">
    <img src="{{ asset('admin/assets/images/fevicon.png') }}" alt="" width="20%">
    <h1 style="font-size: 40px">জলছবি</h1>
</div>
